```
npm install
```
```
npm start
```
http://localhost:8000