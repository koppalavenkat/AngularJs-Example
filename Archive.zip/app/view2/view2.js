'use strict';

angular.module('myApp.view2', ['ngRoute'])
.controller('View2Ctrl', [function($scope) {
  var vm = this
vm.userName= "Hello";
}]);